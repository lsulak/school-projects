using System;
using System.Globalization;
using System.Windows.Data;
using Cookbook.Model;

namespace Cookbook.Desktop.Converters
{
    public class RemoveRecipeFromMealConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            return new Tuple<DailyMeal, Recipe>(values[0] as DailyMeal, values[1] as Recipe);
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}