﻿using System;
using System.Windows;
using Cookbook.Services;
using Cookbook.ViewModels.ViewModels;

namespace Cookbook.Desktop.Windows
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MainWindowClosed(object sender, EventArgs e)
        {
            var mainViewModel = this.MainGrid.DataContext as MainViewModel;
            if (mainViewModel != null)
                mainViewModel.SaveAndDispose();
        }
    }
}
