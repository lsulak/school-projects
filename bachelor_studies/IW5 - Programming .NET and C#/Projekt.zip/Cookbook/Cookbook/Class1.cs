﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model;
using Cookbook.Model.Enums;
using Cookbook.Services.Services;

namespace Cookbook
{
    public class Class1
    {
        private static int Main(string[] args)
        {
            using (var service = new RecipeService())
            {
                service.LoadAll();
                Recipe r = new Recipe("Recept", 10, Dish.Soup, "Some instructions");
                r.Ingredients.Add(new UsableIngredient(new Ingredient("Mrkva"), 2));
                service.Add(r);
                service.Save();

                foreach (var recipe in service.GetObservableCollection())
                {
                    Console.WriteLine("{0} {1} {2} {3} {4} {5}", recipe.Name, recipe.PreparationTime, recipe.DishType, recipe.Instructions, recipe.Ingredients[0].Ingredient.Name, recipe.Ingredients[0].Amount);
                }
            }
            Console.ReadKey();
            return 0;
        }
    }
}
