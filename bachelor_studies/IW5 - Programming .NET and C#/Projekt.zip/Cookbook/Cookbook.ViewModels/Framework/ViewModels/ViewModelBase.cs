﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;

using Cookbook.Model;
using Cookbook.Model.Base;
using Cookbook.Services;
using Cookbook.Services.Services;
using Cookbook.Services.Services.Repository;
using Cookbook.ViewModels.Annotations;


namespace Cookbook.ViewModels.Framework.ViewModels
{
    public abstract class ViewModelBase<T> : INotifyPropertyChanged, IDisposable where T : Entity
    {
        private bool _disposed;

        private string _name;

        public string Name
        {
            get
            {
                return _name;
            }
            set
            { 
                if (value == _name)
                {
                    return;
                }
                _name = value;
                OnPropertyChanged();
                
            }
        }

        public Repository<CookBookDbContext, T> Service { get; protected set; }

        public event PropertyChangedEventHandler PropertyChanged;

        ~ViewModelBase()
        {
            this.Dispose(false);
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        public abstract void LoadData();

        public virtual void SaveData()
        {
            this.Service.Save();
        }

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            var handler = this.PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void Dispose(bool disposing)
        {
            if (!this._disposed)
            {
                if (disposing)
                {
                    this.Service.Dispose();
                }
                this._disposed = true;
            }
        }
    }
}
