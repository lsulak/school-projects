﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Cookbook.Model.Base;
using Cookbook.ViewModels.Commands.Collection;

namespace Cookbook.ViewModels.Framework.ViewModels
{
    public abstract class ViewModelCollection<T> : ViewModelBase<T> where T : Entity, new()
    {
        private T _newItem;

        public ICommand AddItem { get; set; }
        public ICommand SaveNewItem { get; set; }
        public ICommand DiscardNewItem { get; set; }
        public ICommand RemoveItem { get; set; }

        public ObservableCollection<T> Items
        {
            get
            {
                return this.Service.GetObservableCollection();
            }
        }

        public T NewItem
        {
            get
            {
                return _newItem;
            }
            set
            {
                if (Equals(value, _newItem))
                {
                    return;
                }
                _newItem = value;

                OnPropertyChanged();
            }
        }

        protected ViewModelCollection()
        {
            this.RemoveItem = new RemoveItemCommand<T>(this);
            this.AddItem = new AddItemCommand<T>(this);
            this.SaveNewItem = new SaveItemCommand<T>(this);
            this.DiscardNewItem = new DiscardItemCommand<T>(this);
        }

        public async override void LoadData()
        {
            await Task.Delay(1000);
            this.Service.LoadAll();

            OnPropertyChanged("Items");
        }
    }
}
