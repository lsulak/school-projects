﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model.Base;
using Cookbook.Model.Interfaces;

namespace Cookbook.ViewModels.Framework.ViewModels
{
    public class ViewModelItem<T> : ViewModelBase<T> where T : Entity, IInitializable, new()
    {
        private bool _loaded;
        private T _item;
        public T Item
        {
            get
            {
                if (!_loaded)
                    return null;

                if (this._item == null)
                {
                    if (this.Service.GetObservableCollection().Count > 0)
                        _item = this.Service.GetObservableCollection()[0];
                    else
                    {
                        _item = new T();
                        _item.Init();
                        this.Service.Add(_item);
                    }
                }

                return _item;
            }
            private set { this._item = value; }
        }

        public ViewModelItem()
        {
            this.Item = null;
            this._loaded = false;
        }

        public async override void LoadData()
        {
            await Task.Delay(1000);
            this.Service.LoadAll();

            _loaded = true;
            OnPropertyChanged("Item");
        }
    }
}
