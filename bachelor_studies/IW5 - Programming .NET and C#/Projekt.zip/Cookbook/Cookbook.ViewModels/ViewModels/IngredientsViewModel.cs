﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Cookbook.Model;
using Cookbook.Services.Services;
using Cookbook.ViewModels.Commands.Recipes;
using Cookbook.ViewModels.Framework.ViewModels;

namespace Cookbook.ViewModels.ViewModels
{
    public class IngredientsViewModel : ViewModelCollection<Ingredient>
    {
        public ICommand ManageRecipes { get; set; }

        private bool _managed;
        public bool Managed
        {
            get { return _managed; }
            set
            {
                _managed = value;
                OnPropertyChanged();
            }
        }

        public IngredientsViewModel()
        {
            this.Name = "Ingredients";
            this.Service = new IngredientService();
            this.ManageRecipes = new ManageRecipesCommand(this);
            this.Managed = false;
            base.LoadData();
        }
    }
}
