﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model.Base;
using Cookbook.Services;
using Cookbook.ViewModels.Framework.ViewModels;

namespace Cookbook.ViewModels.ViewModels
{
    public class MainViewModel
    {
        public RecipesViewModel RecipesViewModel { get; set; }
        public MenuViewModel MenuViewModel { get; set; }

        public MainViewModel()
        {
            this.RecipesViewModel = new RecipesViewModel();
            this.MenuViewModel = new MenuViewModel();
        }

        public void SaveAndDispose()
        {
            this.RecipesViewModel.SaveData();
            this.MenuViewModel.SaveData();
            SharedContextLoader<CookBookDbContext>.Dispose();
        }
    }
}
