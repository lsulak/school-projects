﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

using Cookbook.Model;
using Cookbook.ViewModels.Framework.ViewModels;
using Cookbook.Services.Services;
using Cookbook.ViewModels.Annotations;
using Cookbook.ViewModels.Commands.Recipes;

namespace Cookbook.ViewModels.ViewModels
{
    public class RecipesViewModel : ViewModelCollection<Recipe>
    {
        public IngredientsViewModel IngredientsViewModel { get; set; }
        public ICommand AddRecipeIngredient { get; set; }
        public ICommand RemoveRecipeIngredient { get; set; }
        public ICommand ManageIngredients { get; set; }

        public RecipesViewModel()
        {
            this.IngredientsViewModel = new IngredientsViewModel();

            this.Name = "Recipes";
            this.Service = new RecipeService();
            this.AddRecipeIngredient = new AddRecipeIngredientCommand(this);
            this.RemoveRecipeIngredient = new RemoveRecipeIngredientCommand(this);
            this.ManageIngredients = new ManageIngredientsCommand(this);
            base.LoadData();
        }

        public override void SaveData()
        {
            this.IngredientsViewModel.SaveData();
            base.SaveData();
        }
    }
}
