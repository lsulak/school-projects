﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Cookbook.Model;
using Cookbook.Model.Enums;
using Cookbook.Services.Services;
using Cookbook.ViewModels.Commands.Menu;
using Cookbook.ViewModels.Framework.ViewModels;

namespace Cookbook.ViewModels.ViewModels
{
    public class MenuViewModel : ViewModelItem<Menu>
    {
        private DailyMeal _mealManaged;

        public DailyMeal MealManaged
        {
            get { return _mealManaged; }
            set
            {
                _mealManaged = value;
                OnPropertyChanged();
            }
        }

        public ICommand AddRecipeToMeal { get; set; }
        public ICommand CancelAddRecipeToMeal { get; set; }
        public ICommand SaveRecipeToMeal { get; set; }
        public ICommand RemoveRecipeFromMeal { get; set; }

        public MenuViewModel()
        {
            this.Name = "Menu";
            this.Service = new MenuService();
            this.AddRecipeToMeal = new AddRecipeToMealCommand(this);
            this.CancelAddRecipeToMeal = new CancelAddRecipeToMealCommand(this);
            this.SaveRecipeToMeal = new SaveRecipeToMealCommand(this);
            this.RemoveRecipeFromMeal = new RemoveRecipeFromMealCommand(this);
            this.MealManaged = null;
            base.LoadData();
        }
    }
}
