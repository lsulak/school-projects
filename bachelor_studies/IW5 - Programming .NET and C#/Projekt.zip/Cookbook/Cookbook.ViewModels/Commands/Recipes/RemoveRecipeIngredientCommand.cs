﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model;
using Cookbook.ViewModels.Framework.Commands;
using Cookbook.ViewModels.ViewModels;

namespace Cookbook.ViewModels.Commands.Recipes
{
    class RemoveRecipeIngredientCommand : CommandBase<RecipesViewModel>
    {
        public RemoveRecipeIngredientCommand(RecipesViewModel viewModel) : base(viewModel)
        {
        }

        public override void Execute(object item)
        {
            var ingredient = item as UsableIngredient;
            if (ingredient == null)
                return;

            this.ViewModel.NewItem.Ingredients.Remove(ingredient);
        }
    }
}
