﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model;
using Cookbook.ViewModels.Framework.Commands;
using Cookbook.ViewModels.Framework.ViewModels;
using Cookbook.ViewModels.ViewModels;

namespace Cookbook.ViewModels.Commands.Recipes
{
    public class AddRecipeIngredientCommand : CommandBase<RecipesViewModel>
    {
        public AddRecipeIngredientCommand(RecipesViewModel viewModel) : base(viewModel)
        {
        }

        public override void Execute(object item)
        {
            this.ViewModel.NewItem.Ingredients.Add(new UsableIngredient());
        }
    }
}
