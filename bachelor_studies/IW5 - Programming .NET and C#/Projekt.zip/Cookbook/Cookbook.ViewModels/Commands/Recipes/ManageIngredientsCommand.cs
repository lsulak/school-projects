﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model;
using Cookbook.ViewModels.Framework.Commands;
using Cookbook.ViewModels.ViewModels;

namespace Cookbook.ViewModels.Commands.Recipes
{
    class ManageIngredientsCommand : CommandBase<RecipesViewModel>
    {
        public ManageIngredientsCommand(RecipesViewModel viewModel) : base(viewModel)
        {
        }

        public override void Execute(object item)
        {
            this.ViewModel.IngredientsViewModel.Managed = true;
        }
    }
}
