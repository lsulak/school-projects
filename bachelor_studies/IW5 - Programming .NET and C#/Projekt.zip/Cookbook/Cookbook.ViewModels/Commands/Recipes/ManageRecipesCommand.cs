﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.ViewModels.Framework.Commands;
using Cookbook.ViewModels.ViewModels;

namespace Cookbook.ViewModels.Commands.Recipes
{
    public class ManageRecipesCommand : CommandBase<IngredientsViewModel>
    {
        public ManageRecipesCommand(IngredientsViewModel viewModel) : base(viewModel)
        {
        }

        public override void Execute(object item)
        {
            this.ViewModel.Managed = false;
        }
    }
}
