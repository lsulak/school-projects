﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model;
using Cookbook.ViewModels.Framework.Commands;
using Cookbook.ViewModels.ViewModels;

namespace Cookbook.ViewModels.Commands.Menu
{
    public class RemoveRecipeFromMealCommand : CommandBase<MenuViewModel>
    {
        public RemoveRecipeFromMealCommand(MenuViewModel viewModel) : base(viewModel)
        {
        }

        public override void Execute(object parameter)
        {
            var tuple = parameter as Tuple<DailyMeal, Recipe>;
            if (tuple == null)
                return;

            tuple.Item1.Recipes.Remove(tuple.Item2);
        }
    }
}
