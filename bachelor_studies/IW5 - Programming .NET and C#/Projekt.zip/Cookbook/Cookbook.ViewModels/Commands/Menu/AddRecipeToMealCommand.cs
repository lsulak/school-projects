﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model;
using Cookbook.ViewModels.Framework.Commands;
using Cookbook.ViewModels.ViewModels;

namespace Cookbook.ViewModels.Commands.Menu
{
    public class AddRecipeToMealCommand : CommandBase<MenuViewModel>
    {
        public AddRecipeToMealCommand(MenuViewModel viewModel) : base(viewModel)
        {
        }

        public override void Execute(object parameter)
        {
            var meal = parameter as DailyMeal;
            if (meal == null)
                return;

            ViewModel.MealManaged = meal;
        }
    }
}
