﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Cookbook.ViewModels.Framework.Commands;
using Cookbook.ViewModels.ViewModels;

namespace Cookbook.ViewModels.Commands.Menu
{
    public class CancelAddRecipeToMealCommand : CommandBase<MenuViewModel>
    {
        public CancelAddRecipeToMealCommand(MenuViewModel viewModel) : base(viewModel)
        {
        }

        public override void Execute(object parameter)
        {
            this.ViewModel.MealManaged = null;
        }
    }
}
