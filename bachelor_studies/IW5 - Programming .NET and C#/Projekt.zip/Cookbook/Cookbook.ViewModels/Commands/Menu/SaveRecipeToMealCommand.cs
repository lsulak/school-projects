﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model;
using Cookbook.ViewModels.Framework.Commands;
using Cookbook.ViewModels.ViewModels;

namespace Cookbook.ViewModels.Commands.Menu
{
    public class SaveRecipeToMealCommand : CommandBase<MenuViewModel>
    {
        public SaveRecipeToMealCommand(MenuViewModel viewModel) : base(viewModel)
        {
        }

        public override void Execute(object parameter)
        {
            var recipe = parameter as Recipe;
            if (recipe == null)
                return;

            this.ViewModel.MealManaged.Recipes.Add(recipe);
            this.ViewModel.MealManaged = null;
        }
    }
}
