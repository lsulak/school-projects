﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model.Base;
using Cookbook.ViewModels.Framework.Commands;
using Cookbook.ViewModels.Framework.ViewModels;

namespace Cookbook.ViewModels.Commands.Collection
{
    public class RemoveItemCommand<T> : CommandBase<ViewModelCollection<T>> where T : Entity, new()
    {
        public RemoveItemCommand(ViewModelCollection<T> viewModelCollection) : base(viewModelCollection)
        {
        }

        public override void Execute(object item)
        {
            var typeItem = item as T;
            if (typeItem != null)
            {
                this.ViewModel.Items.Remove(typeItem);
            }
        }
    }
}
