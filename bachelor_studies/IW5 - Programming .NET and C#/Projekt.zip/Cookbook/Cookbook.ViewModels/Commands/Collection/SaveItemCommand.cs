﻿using Cookbook.Model.Base;
using Cookbook.ViewModels.Framework.Commands;
using Cookbook.ViewModels.Framework.ViewModels;

namespace Cookbook.ViewModels.Commands.Collection
{
    public class SaveItemCommand<T> : CommandBase<ViewModelCollection<T>> where T : Entity, new()
    {
        public SaveItemCommand(ViewModelCollection<T> viewModelCollection) : base(viewModelCollection)
        {
        }

        public override void Execute(object item)
        {
            this.ViewModel.Service.Add(this.ViewModel.NewItem);
            this.ViewModel.Items.Add(this.ViewModel.NewItem);
            this.ViewModel.NewItem = null;
        }
    }
}
