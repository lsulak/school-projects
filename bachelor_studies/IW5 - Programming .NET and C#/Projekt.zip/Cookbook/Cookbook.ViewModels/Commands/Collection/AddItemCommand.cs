﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model;
using Cookbook.Model.Base;
using Cookbook.ViewModels.Framework.Commands;
using Cookbook.ViewModels.Framework.ViewModels;

namespace Cookbook.ViewModels.Commands.Collection
{
    public class AddItemCommand<T> : CommandBase<ViewModelCollection<T>> where T : Entity, new()
    {
        public AddItemCommand(ViewModelCollection<T> viewModel) : base(viewModel)
        {
        }

        public override void Execute(object item)
        {
            this.ViewModel.NewItem = new T();
        }
    }
}
