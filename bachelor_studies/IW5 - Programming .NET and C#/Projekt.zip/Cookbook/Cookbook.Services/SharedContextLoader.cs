﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cookbook.Services
{
    public class SharedContextLoader<T> where T : class, IDisposable, new()
    {
        private static T _context = new T();

        private SharedContextLoader()
        {
        }

        public static T Context
        {
            get
            {
                return _context;
            }
        }

        public static void Dispose()
        {
            _context.Dispose();
        }
    }
}
