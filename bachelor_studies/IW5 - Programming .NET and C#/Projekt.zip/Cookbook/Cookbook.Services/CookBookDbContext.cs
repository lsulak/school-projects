﻿using System;
using System.Data.Entity;
using Cookbook.Model;


namespace Cookbook.Services
{
    public class CookBookDbContext : DbContext
    {
        public DbSet<Ingredient> Ingredient { get; set; }
        public DbSet<UsableIngredient> UsableIngredient { get; set; }
        public DbSet<BuyableIngredient> BuyableIngredient { get; set; }
        public DbSet<Recipe> Recipe { get; set; }
        public DbSet<DailyMeal> DailyMeal { get; set; }
        public DbSet<DailyMenu> DailyMenu { get; set; }
        public DbSet<Menu> Menu { get; set; }
        public DbSet<ShoppingList> ShoppingList { get; set; }

        public CookBookDbContext()
            : base(@"Data Source=(LocalDB)\v11.0;AttachDbFileName=C:\Users\Ladislav\IW5 Project\Cookbook\IW5 Project\Cookbook\Cookbook.Services\LocalDatabase.mdf;Persist Security Info=True;MultipleActiveResultSets=True;Integrated Security=SSPI")
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<CookBookDbContext, CookBookDbMigrationsConfiguration<CookBookDbContext>>());
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Ingredient>().ToTable("Ingredient");
            modelBuilder.Entity<UsableIngredient>().ToTable("UsableIngredient");
            modelBuilder.Entity<BuyableIngredient>().ToTable("BuyableIngredient");
            modelBuilder.Entity<Recipe>().ToTable("Recipe");
            modelBuilder.Entity<DailyMeal>().ToTable("DailyMeal");
            modelBuilder.Entity<DailyMenu>().ToTable("DailyMenu");
            modelBuilder.Entity<Menu>().ToTable("Menu");
            modelBuilder.Entity<ShoppingList>().ToTable("ShoppingList");
        }
    }
}
