﻿CREATE TABLE [dbo].[Menu]
(
	[Id] UNIQUEIDENTIFIER NOT NULL,
	[DailyMenus] UNIQUEIDENTIFIER NULL,
	CONSTRAINT [PK_dbo.Menu] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_dbo.DailyMenu_dbo.FK_DailyMenu_Menu_Assign_Id] FOREIGN KEY ([DailyMenus]) REFERENCES [dbo].[DailyMenu] ([Id])
)
