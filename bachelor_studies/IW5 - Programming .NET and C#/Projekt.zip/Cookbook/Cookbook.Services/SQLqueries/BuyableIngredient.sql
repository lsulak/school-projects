﻿CREATE TABLE [dbo].[BuyableIngredient]
(
	[Id] UNIQUEIDENTIFIER NOT NULL, 
	[BoughtAmount] INT NULL, 
	[ToBuyAmount] INT NULL,
	[Item] UNIQUEIDENTIFIER NULL,
	CONSTRAINT [PK_dbo.BuyableIngredient] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_dbo.Ingredient_dbo.FK_Ingredient_BuyableIngredient_Assign_Id] FOREIGN KEY ([Item]) REFERENCES [dbo].[Ingredient] ([Id])
)
