﻿CREATE TABLE [dbo].[Recipe]
(
	[Id] UNIQUEIDENTIFIER NOT NULL, 
	[Name] NVARCHAR(MAX) NULL,
	[PreparationTime] INT NULL,
	[DishType] INT NULL,
	[Instructions] NVARCHAR(MAX) NULL,
	[Ingredients] UNIQUEIDENTIFIER NULL,
	CONSTRAINT [PK_dbo.Recipe] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_dbo.UsableIngredient_dbo.FK_UsableIngredient_Recipe_Assign_Id] FOREIGN KEY ([Ingredients]) REFERENCES [dbo].[UsableIngredient] ([Id])
)
