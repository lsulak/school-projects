﻿CREATE TABLE [dbo].[DailyMenu]
(
	[Id] UNIQUEIDENTIFIER NOT NULL,
	[Day] INT NULL, 
	[Meals] UNIQUEIDENTIFIER NULL, 
	CONSTRAINT [PK_dbo.DailyMenu] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_dbo.DailyMeal_dbo.FK_DailyMeal_DailyMenu_Assign_Id] FOREIGN KEY ([Meals]) REFERENCES [dbo].[DailyMeal] ([Id])
)
