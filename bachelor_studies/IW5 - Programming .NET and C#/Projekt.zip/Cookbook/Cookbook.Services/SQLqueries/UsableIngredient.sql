﻿CREATE TABLE [dbo].[UsableIngredient]
(
	[Id] UNIQUEIDENTIFIER NOT NULL,
	[Item] UNIQUEIDENTIFIER NULL, 
	[Amount] INT NULL,
	CONSTRAINT [PK_dbo.UsableIngredient] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_dbo.Ingredient_dbo.FK_Ingredient_UsableIngredient_Assign_Id] FOREIGN KEY ([Item]) REFERENCES [dbo].[Ingredient] ([Id])
)
