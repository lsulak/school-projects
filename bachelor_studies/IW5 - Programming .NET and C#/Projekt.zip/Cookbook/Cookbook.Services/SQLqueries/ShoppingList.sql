﻿CREATE TABLE [dbo].[ShoppingList]
(
	[Id] UNIQUEIDENTIFIER NOT NULL,
	[ItemList] UNIQUEIDENTIFIER NULL, 
	CONSTRAINT [PK_dbo.ShoppingList] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_dbo.BuyableIngredient_dbo.FK_BuyableIngredient_ShoppingList_Assign_Id] FOREIGN KEY ([ItemList]) REFERENCES [dbo].[BuyableIngredient] ([Id])
)
