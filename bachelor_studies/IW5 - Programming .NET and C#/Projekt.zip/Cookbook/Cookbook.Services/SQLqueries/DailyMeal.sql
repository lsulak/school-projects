CREATE TABLE [dbo].[DailyMeal]
(
	[Id] UNIQUEIDENTIFIER NOT NULL,
	[Meal] INT NULL, 
	[Recipes] UNIQUEIDENTIFIER NULL, 
	CONSTRAINT [PK_dbo.DailyMeal] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_dbo.Recipe_dbo.FK_Recipes_DailyMeal_Assign_Id] FOREIGN KEY ([Recipes]) REFERENCES [dbo].[Recipe] ([Id])
)
