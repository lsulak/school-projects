﻿CREATE TABLE [dbo].[CookBook]
(
	[Id] UNIQUEIDENTIFIER NOT NULL,
	[Recipes] UNIQUEIDENTIFIER NULL, 
	CONSTRAINT [PK_dbo.CookBook] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_dbo.Recipe_dbo.FK_Recipe_CookBook_Assign_Id] FOREIGN KEY ([Recipes]) REFERENCES [dbo].[Recipe] ([Id])
)
