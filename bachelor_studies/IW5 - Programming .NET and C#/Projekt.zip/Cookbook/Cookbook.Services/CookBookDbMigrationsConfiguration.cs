﻿using System.Data.Entity;
using System.Data.Entity.Migrations;

namespace Cookbook.Services
{
    public class CookBookDbMigrationsConfiguration<T> : DbMigrationsConfiguration<T> where T : DbContext
    {
        public CookBookDbMigrationsConfiguration()
        {
            AutomaticMigrationsEnabled = true;
        }
    }
}
