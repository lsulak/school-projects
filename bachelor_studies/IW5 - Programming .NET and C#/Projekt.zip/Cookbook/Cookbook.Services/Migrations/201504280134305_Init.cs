namespace Cookbook.Services.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Init : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.BuyableIngredient",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        BoughtAmount = c.Int(nullable: false),
                        ToBuyAmount = c.Int(nullable: false),
                        Ingredient_Id = c.Guid(),
                        ShoppingList_Id = c.Guid(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Ingredient", t => t.Ingredient_Id)
                .ForeignKey("dbo.ShoppingList", t => t.ShoppingList_Id)
                .Index(t => t.Ingredient_Id)
                .Index(t => t.ShoppingList_Id);
            
            CreateTable(
                "dbo.Ingredient",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.DailyMeal",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Meal = c.Int(nullable: false),
                        DailyMenu_Id = c.Guid(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.DailyMenu", t => t.DailyMenu_Id)
                .Index(t => t.DailyMenu_Id);
            
            CreateTable(
                "dbo.Recipe",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Name = c.String(),
                        PreparationTime = c.Int(nullable: false),
                        DishType = c.Int(nullable: false),
                        Instructions = c.String(),
                        DailyMeal_Id = c.Guid(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.DailyMeal", t => t.DailyMeal_Id)
                .Index(t => t.DailyMeal_Id);
            
            CreateTable(
                "dbo.UsableIngredient",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Amount = c.Int(nullable: false),
                        Ingredient_Id = c.Guid(),
                        Recipe_Id = c.Guid(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Ingredient", t => t.Ingredient_Id)
                .ForeignKey("dbo.Recipe", t => t.Recipe_Id)
                .Index(t => t.Ingredient_Id)
                .Index(t => t.Recipe_Id);
            
            CreateTable(
                "dbo.DailyMenu",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Day = c.Int(nullable: false),
                        Menu_Id = c.Guid(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Menu", t => t.Menu_Id)
                .Index(t => t.Menu_Id);
            
            CreateTable(
                "dbo.Menu",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.ShoppingList",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.BuyableIngredient", "ShoppingList_Id", "dbo.ShoppingList");
            DropForeignKey("dbo.DailyMenu", "Menu_Id", "dbo.Menu");
            DropForeignKey("dbo.DailyMeal", "DailyMenu_Id", "dbo.DailyMenu");
            DropForeignKey("dbo.Recipe", "DailyMeal_Id", "dbo.DailyMeal");
            DropForeignKey("dbo.UsableIngredient", "Recipe_Id", "dbo.Recipe");
            DropForeignKey("dbo.UsableIngredient", "Ingredient_Id", "dbo.Ingredient");
            DropForeignKey("dbo.BuyableIngredient", "Ingredient_Id", "dbo.Ingredient");
            DropIndex("dbo.DailyMenu", new[] { "Menu_Id" });
            DropIndex("dbo.UsableIngredient", new[] { "Recipe_Id" });
            DropIndex("dbo.UsableIngredient", new[] { "Ingredient_Id" });
            DropIndex("dbo.Recipe", new[] { "DailyMeal_Id" });
            DropIndex("dbo.DailyMeal", new[] { "DailyMenu_Id" });
            DropIndex("dbo.BuyableIngredient", new[] { "ShoppingList_Id" });
            DropIndex("dbo.BuyableIngredient", new[] { "Ingredient_Id" });
            DropTable("dbo.ShoppingList");
            DropTable("dbo.Menu");
            DropTable("dbo.DailyMenu");
            DropTable("dbo.UsableIngredient");
            DropTable("dbo.Recipe");
            DropTable("dbo.DailyMeal");
            DropTable("dbo.Ingredient");
            DropTable("dbo.BuyableIngredient");
        }
    }
}
