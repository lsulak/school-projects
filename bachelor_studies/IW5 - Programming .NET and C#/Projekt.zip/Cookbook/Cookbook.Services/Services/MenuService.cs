﻿using System;
using System.Data.Entity;
using System.Linq;
using Cookbook.Model;
using Cookbook.Services.Services.Repository;

namespace Cookbook.Services.Services
{
    public class MenuService : Repository<CookBookDbContext, Menu>
    {
        public override void LoadAll()
        {
            base.LoadAll();

            this.Context.Menu.Select(m => m.DailyMenus).Load();
            this.Context.DailyMenu.Select(dm => dm.Meals).Load();
            this.Context.DailyMeal.Select(dm => dm.Recipes).Load();
            this.Context.Recipe.Select(r => r.Ingredients).Load();
            this.Context.UsableIngredient.Select(i => i.Ingredient).Load();
        }
    }
}
