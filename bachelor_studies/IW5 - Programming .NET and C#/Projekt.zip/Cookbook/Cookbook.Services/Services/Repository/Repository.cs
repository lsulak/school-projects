﻿using System;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using Cookbook.Model.Base;

namespace Cookbook.Services.Services.Repository
{
    public class Repository<TContext, T> : IDisposable, IRepository<T>
        where T : Entity
        where TContext : DbContext, new()
    {
        private bool _disposed;

        protected TContext Context
        {
            get { return SharedContextLoader<TContext>.Context; }
        }

        public virtual T Add(T entity)
        {
            return this.Context.Set<T>().Add(entity);
        }

        public virtual void Delete(T entity)
        {
            this.Context.Set<T>().Remove(entity);
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        public virtual void Edit(T entity)
        {
            this.Context.Entry(entity).State = EntityState.Modified;
        }

        public virtual IQueryable<T> FindBy(Expression<Func<T, bool>> predicate)
        {
            IQueryable<T> query = this.Context.Set<T>().Where(predicate);
            return query;
        }

        public virtual IQueryable<T> GetAll()
        {
            return this.Context.Set<T>();
        }

        public virtual T GetById(Guid id)
        {
            return this.Context.Set<T>().Single(i => i.Id == id);
        }

        public ObservableCollection<T> GetObservableCollection()
        {
            return this.Context.Set<T>().Local;
        }

        public virtual void LoadAll()
        {
            this.Context.Set<T>().Load();
        }

        public virtual void Save()
        {
            this.Context.SaveChanges();
        }

        private void Dispose(bool disposing)
        {
            if (!this._disposed)
            {
                if (disposing)
                {
                    this.Context.Dispose();
                }
                this._disposed = true;
            }
        }
    }
}
