﻿using System;
using Cookbook.Model;
using Cookbook.Services.Services.Repository;

namespace Cookbook.Services.Services
{
    public class IngredientService : Repository<CookBookDbContext, Ingredient>
    {
    }
}
