﻿using System;
using System.Data.Entity;
using System.Linq;
using Cookbook.Model;
using Cookbook.Services.Services.Repository;

namespace Cookbook.Services.Services
{
    public class RecipeService : Repository<CookBookDbContext, Recipe>
    {
        public override void LoadAll()
        {
            base.LoadAll();

            this.Context.Recipe.Select(r => r.Ingredients).Load();
            this.Context.UsableIngredient.Select(i => i.Ingredient).Load();
        }
    }
}
