﻿using System;
using System.Linq;
using Cookbook.Model;
using Cookbook.Services.Services.Repository;
using System.Data.Entity;

namespace Cookbook.Services.Services
{
    public class BuyableIngredientService : Repository<CookBookDbContext, BuyableIngredient>
    {
        public override void LoadAll()
        {
            base.LoadAll();

            this.Context.BuyableIngredient.Select(i => i.Ingredient).Load();
        }
    }
}
