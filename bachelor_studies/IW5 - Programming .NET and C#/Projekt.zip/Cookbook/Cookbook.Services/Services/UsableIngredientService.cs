﻿using System;
using System.Data.Entity;
using System.Linq;
using Cookbook.Model;
using Cookbook.Services.Services.Repository;

namespace Cookbook.Services.Services
{
    public class UsableIngredientService : Repository<CookBookDbContext, UsableIngredient>
    {
        public override void LoadAll()
        {
            base.LoadAll();

            this.Context.UsableIngredient.Select(i => i.Ingredient).Load();
        }
    }
}
