﻿using System;
using System.Data.Entity;
using System.Linq;
using Cookbook.Model;
using Cookbook.Services.Services.Repository;

namespace Cookbook.Services.Services
{
    public class ShoppingListService : Repository<CookBookDbContext, ShoppingList>
    {
        public override void LoadAll()
        {
            base.LoadAll();

            this.Context.ShoppingList.Select(sl => sl.ItemList).Load();
            this.Context.BuyableIngredient.Select(i => i.Ingredient).Load();
        }
    }
}
