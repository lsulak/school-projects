﻿using System;
using System.Data.Entity;
using System.Linq;
using Cookbook.Model;
using Cookbook.Services.Services.Repository;

namespace Cookbook.Services.Services
{
    public class DailyMealService : Repository<CookBookDbContext, DailyMeal>
    {
        public override void LoadAll()
        {
            base.LoadAll();

            this.Context.DailyMeal.Select(dm => dm.Recipes).Load();
            this.Context.Recipe.Select(r => r.Ingredients).Load();
            this.Context.UsableIngredient.Select(i => i.Ingredient).Load();
        }
    }
}
