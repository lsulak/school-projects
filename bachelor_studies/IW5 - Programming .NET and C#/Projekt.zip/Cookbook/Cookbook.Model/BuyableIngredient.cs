﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model.Base;

namespace Cookbook.Model
{
    public class BuyableIngredient : Entity
    {
        public BuyableIngredient() {}

        public BuyableIngredient(Ingredient ingredient, int toBuyAmount)
        {
            this.Ingredient = ingredient;
            this.BoughtAmount = 0;
            this.ToBuyAmount = toBuyAmount;
        }

        public bool IsBought
        {
            get
            {
                return BoughtAmount == ToBuyAmount;
            }
        }

        public int BoughtAmount { get; set; }
        public int ToBuyAmount { get; set; }
        public Ingredient Ingredient { get; set; }
    }
}
