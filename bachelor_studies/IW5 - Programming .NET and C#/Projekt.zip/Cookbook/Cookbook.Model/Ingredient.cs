﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model.Base;

namespace Cookbook.Model
{
    public class Ingredient : Entity
    {
        public Ingredient() {}

        public Ingredient(string name)
        {
            this.Name = name;
        }

        public override string ToString()
        {
            return this.Name;
        }

        public string Name { get; set; }
    }
}
