﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model.Base;
using Cookbook.Model.Enums;
using Cookbook.Model.Interfaces;

namespace Cookbook.Model
{
    public class DailyMenu : Entity, IInitializable
    {
        public DailyMenu()
        {
            this.Meals = new ObservableCollection<DailyMeal>();
        }

        public DailyMenu(Day day)
        {
            this.Day = day;
            this.Meals = new ObservableCollection<DailyMeal>();
        }

        public void Init()
        {
            foreach (Meal meal in Enum.GetValues(typeof(Meal)))
            {
                this.Meals.Add(new DailyMeal(meal));
            }
        }

        public override string ToString()
        {
            return Day.ToString();
        }

        public Day Day { get; set; }
        public virtual ObservableCollection<DailyMeal> Meals { get; private set; }
    }
}
