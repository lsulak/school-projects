﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model.Base;
using Cookbook.Model.Enums;

namespace Cookbook.Model
{
    public class DailyMeal : Entity
    {
        public DailyMeal()
        {
            this.Meal = Meal.Breakfast;
            this.Recipes = new ObservableCollection<Recipe>();
        }

        public DailyMeal(Meal meal)
        {
            this.Meal = meal;
            this.Recipes = new ObservableCollection<Recipe>();
        }

        public override string ToString()
        {
            return Meal.ToString();
        }

        public Meal Meal { get; set; }
        public virtual ObservableCollection<Recipe> Recipes { get; private set; }
    }
}
