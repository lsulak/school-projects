﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model.Base;

namespace Cookbook.Model
{
    public class UsableIngredient : Entity
    {
        public UsableIngredient() {}

        public UsableIngredient(Ingredient ingredient, int amount)
        {
            this.Ingredient = ingredient;
            this.Amount = amount;
        }

        public override string ToString()
        {
            return Ingredient + " (" + Amount + ")";
        }

        public int Amount { get; set; }
        public Ingredient Ingredient { get; set; }
    }
}
