﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model.Base;
using Cookbook.Model.Enums;
using Cookbook.Model.Interfaces;

namespace Cookbook.Model
{
    public class Menu : Entity, IInitializable
    {
        public Menu()
        {
            this.DailyMenus = new ObservableCollection<DailyMenu>();
        }

        public void Init()
        {
            foreach (Day day in Enum.GetValues(typeof(Day)))
            {
                var dailyMenu = new DailyMenu(day);
                dailyMenu.Init();
                this.DailyMenus.Add(dailyMenu);
            }
        }

        public virtual ObservableCollection<DailyMenu> DailyMenus { get; private set; }
    }
}
