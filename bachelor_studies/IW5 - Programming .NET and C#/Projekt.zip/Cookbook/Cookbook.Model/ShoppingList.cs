﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model.Base;

namespace Cookbook.Model
{
    public class ShoppingList : Entity
    {
        public ShoppingList()
        {
            this.ItemList = new ObservableCollection<BuyableIngredient>();
        }

        public virtual ObservableCollection<BuyableIngredient> ItemList { get; private set; }
    }
}
