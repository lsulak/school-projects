﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cookbook.Model.Base;
using Cookbook.Model.Enums;

namespace Cookbook.Model
{
    public class Recipe : Entity
    {
        public Recipe()
        {
            this.Ingredients = new ObservableCollection<UsableIngredient>();
        }

        public Recipe(string name, int preparationTime, Dish dishType, string instructions)
        {
            this.Name = name;
            this.PreparationTime = preparationTime;
            this.DishType = dishType;
            this.Instructions = instructions;
            this.Ingredients = new ObservableCollection<UsableIngredient>();
        }

        public override string ToString()
        {
            return Name;
        }

        public string Name { get; set; }
        public int PreparationTime { get; set; }
        public Dish DishType { get; set; }
        public string Instructions { get; set; }
        public virtual ObservableCollection<UsableIngredient> Ingredients { get; private set; }
    }
}
