/**
 *  2. Projekt do predmetu Operacne systemy : Santa Claus Problem 
 *  Autor: Ladislav Sulak
 *  Login: xsulak04
 *  Datum: april 2013
 *  Kontakt: xsulak04@stud.fit.vutbr.cz
 *  Popis: synchronizacia procesov pomocou semaforov POSIX. Pouzita zdielana pamat
 *  Pre rychly preklad pouzite make 
 * 
 **/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h> //Pre funkciu isdigit
#include <time.h>

#include <sys/types.h> //Semafory POSIX a zdielana pamat
#include <sys/mman.h>
#include <semaphore.h>
#include <fcntl.h>

#include <sys/wait.h> //wait()
#include <unistd.h> //fork()

typedef struct {		 //3 premenne, ktore nizsie alokujem do zdielanej pamati
	long working_elves;  //Pocet Pracujucich (uspatych) elfov
	long waiting_elves;  //Pocet elfov ktory cakaju na obsluhu
	long sharedA;        //Cislo akcie
} stav;

FILE *santa; //Globalna premenna-pre pracu so suborom- zapisovanie a zatvaranie.

//Prototypy funkcii.Jednotlive funkcionality kazdej budu popisane nizsie.
int parameters(int argc, char *argv[]); 
void proces_santa(long S, stav *sharedVar, sem_t * sem_vypis,sem_t *sem_santa,sem_t *sem_elf,sem_t *sem_cakaj,sem_t *sem_finishElf,sem_t *sem_finishSanta,long shMem);
void proces_skriatok(long C, long E, long H, stav *sharedVar, sem_t * sem_vypis,sem_t *sem_santa,sem_t *sem_elf,sem_t *sem_cakaj,sem_t *sem_finishElf,sem_t *sem_finishSanta,long shMem);
void vypisy_elf(stav *sharedVar, long cislo_skriatka, int sprava, sem_t * sem_vypis);
void vypisy_santa(stav *sharedVar, int sprava, sem_t * sem_vypis);
int clean(sem_t *sem_vypis, sem_t *sem_santa, sem_t *sem_elf, sem_t *sem_cakaj, sem_t *sem_finishElf, sem_t *sem_finishSanta, stav *sharedVar,long shMem);

int main (int argc , char *argv[])
{   
	if(parameters(argc,argv) == 0)
	{ 
		long C,E,H,S;
		
//Do premennych C E H S si postupne ulozim parametre.
		C=strtol(argv[1], NULL, 10); // Prvy parameter-konverzia prveho argumentu na long, druhy parameter null-neuklada adresu prveho chybneho znaku , a
		if(C <= 0) {				 																	  // treti parameter-jedna sa o decimalnu sustavu
			fprintf(stderr, "Prvy parameter musi byt vacsi ako 0!\n");
			return 1;
		}
		E=strtol(argv[2], NULL, 10); 
		if(E <= 0) {
			fprintf(stderr, "Druhy parameter musi byt vacsi ako 0!\n");
			return 1;
		}
		H=strtol(argv[3], NULL, 10);
		S=strtol(argv[4], NULL, 10);

//Vytvorenie semaforov.Nemoze existovat semafor s rovnakym nazvom.Uklada do /dev/shm 
		sem_t *sem_vypis = sem_open("/sem1_xsulak04", O_CREAT | O_EXCL, 0666, 1);  //sluzi na vyhradny zapis do suboru, a tiez pre pracu so zdielanymi premennymi
		sem_t *sem_santa = sem_open("/sem2_xsulak04", O_CREAT | O_EXCL, 0666, 0);  //dava pozor na spravny vypis checked state a naslednej  obsluhy
		sem_t *sem_elf = sem_open("/sem3_xsulak04", O_CREAT | O_EXCL, 0666, 0);      //Obsluha sa musi vykonat az po poziadani o nu, a po jej dokonceni elf musi vypisat ze ju dostal
		sem_t *sem_cakaj = sem_open("/sem4_xsulak04", O_CREAT | O_EXCL, 0666, 0);  //sluzi na to, ze ked je skriatok obsluhovany, iny nemoze o obsluhu pytat
		sem_t *sem_finishElf = sem_open("/sem5_xsulak04", O_CREAT | O_EXCL, 0666, 0); //Tento semafor zariadi ze elfovia koncia vsetci naraz a nakoniec (po obsluhe)
		sem_t *sem_finishSanta = sem_open("/sem6_xsulak04", O_CREAT | O_EXCL, 0666, 0); //semafor urceny pre ukoncenie santu , nastava ak su vsetci elfovia na dovolenke
//Vytvori zdielanu pamat.Uklada do /dev/shm 
		long shMem = shm_open("/sharedMem_xsulak04", O_CREAT | O_EXCL | O_RDWR, 0666);
		if (shMem == -1) { 
			fprintf(stderr,"Nepodarilo sa vytvorit zdielanu pamat alebo semafor\n"); 
			clean(sem_vypis, sem_santa, sem_elf, sem_cakaj, sem_finishElf, sem_finishSanta, NULL, shMem);
			return 2;
			}
//Vyhradime si v nej miesto pre 1 long integer
		ftruncate(shMem, sizeof(stav));
//Mapovanie pamate do adresneho priestoru procesu 
		stav *sharedVar = mmap(NULL, sizeof(stav), PROT_READ | PROT_WRITE, MAP_SHARED, shMem, 0);
//Nastavim pocitadla, ktore su ulozene v strukture ,kt. je v zdielanej pamati
		sharedVar->sharedA = 1;		  //Vypisy zacinaju od cisla 1 (A)
		sharedVar->waiting_elves = 0; //Elfovia cakajuci na obsluhu su na zaciatku 0 , neskor sa inkrementuju
		sharedVar->working_elves = E; //Pracujuci elfovia su na zaciatku = parametru E (pocet elfov na zaciatku)

		if((santa=fopen("santa.out", "w")) == NULL) { //Vytvorenie suboru a osetrenie ci sa ho podarilo vytvorit 
			fprintf(stderr, "Chyba pri vytvarani suboru!\n");
			clean(sem_vypis, sem_santa, sem_elf, sem_cakaj, sem_finishElf, sem_finishSanta, sharedVar, shMem); 	
		 return 2;
		 }
		
		proces_skriatok(C, E,H,sharedVar,sem_vypis,sem_santa,sem_elf,sem_cakaj,sem_finishElf,sem_finishSanta,shMem); //Funkcia pre skriatka
		proces_santa(S, sharedVar,sem_vypis,sem_santa,sem_elf,sem_cakaj,sem_finishElf,sem_finishSanta, shMem);       //Funkcia pre Santu

		if(fclose(santa) == EOF ) {  //Zatvorenie suboru , a osetrenie ci sa ho podarilo zatvorit
			fprintf(stderr, "Subor sa nepodarilo uzavriet!\n" );
			clean(sem_vypis, sem_santa, sem_elf, sem_cakaj, sem_finishElf, sem_finishSanta, sharedVar, shMem);
		return 2;
		}
		
		if(clean(sem_vypis, sem_santa, sem_elf, sem_cakaj, sem_finishElf, sem_finishSanta, sharedVar, shMem) == 0) //Zrusenie zdielanej pamate a semaforov
			return 0;
		else
			return 2;
	}
    else
		return 1;
} 

//Funkcia ktora zisti ci su zadane 4 parametre, a ci su vsetky cele cisla
int parameters(int argc, char *argv[])
{
	if((argc==5) && (isdigit(*argv[1])) && (isdigit(*argv[2])) && (isdigit(*argv[3])) && (isdigit(*argv[4])))
		return 0;
	else
	{   
		fprintf(stderr, "Zadajte 4 celociselne parametre!\n");
		return 1;
	}
}

//Funkcia pre vytvorenie santy, riadenie obsluhy skriatkov
void proces_santa(long S, stav *sharedVar, sem_t * sem_vypis,sem_t *sem_santa,sem_t *sem_elf,sem_t *sem_cakaj,sem_t *sem_finishElf,sem_t *sem_finishSanta,long shMem) {
		srand(getpid()*time(NULL));  //Pre nahodne hodnoty 
		pid_t pid_santa;
		pid_santa=fork();  //Vytvori proces santu, ak je navratova hodnota = 0 , jedna sa o potomka , ak je -1 nepodarilo sa vytvorit proces, a ak je > 0 , jedna sa o rodica
		if(pid_santa == 0) {
			vypisy_santa(sharedVar , 1, sem_vypis);
			
			sem_post(sem_cakaj);   //Hned ako santa zacne, odomkne semafor 
				while(sharedVar->working_elves > 0) 
				{ 
					sem_wait(sem_santa);  //Caka na odblokovanie, elf ho odblokuje ked vypise asked for help

					if((sharedVar->working_elves) > 3) //Ak je pracujuchch elfov viac ako 3, tak nastava prvy sposob obsluhy skriatkov.
					{
						while((sharedVar->waiting_elves) != 3)  //Prvy sposob obsluhy je taky, ze sa caka pokial niesu traja cakajuci elfovia, a potom sa obsluha vykona raz
							{
								sem_post(sem_cakaj);  //Inkrementuje hodnotu semaforu , robi to pokial niesu traja elfovia ktori cakaju na obsluhy
								sem_wait(sem_santa);  //Odblokuje sa , a moze nastat Prvy sposo obsluhy- obsluha trojice skriatkov
							}
					}
						vypisy_santa(sharedVar , 2 , sem_vypis);
						vypisy_santa(sharedVar , 3 , sem_vypis);
				  		if(S == 0)							// Ak je parameter S=0, tak nastane chyba, pretoze nie je mozne delit nulou 
							usleep((rand() % (S +1))*1000); //Uspi-obsluzi skriatka. *1000 preto , ze parameter S je v milisekundach , a usleep obsahuje parameter v mikrosekundach
						else
							usleep((rand() % S)*1000);

						sem_post(sem_elf);   //Po dokonceni obsluhy odblokuje semafor pre elfa, a on vypise got help
			    }

			exit(0);
		}
		else if(pid_santa == -1) //Ak sa nepodari forknut proces 
		{
			fprintf(stderr,"Zlyhalo systemove volanie fork!\n");
			clean(sem_vypis, sem_santa,sem_elf, sem_cakaj, sem_finishElf, sem_finishSanta, sharedVar,shMem);
			exit(2);
		}
		else if(pid_santa > 0) {
			int status;
        	wait(&status);		//Cakanie na skoncenie child procesu....Neukonci sa hned.
		}  
//Ak bude pocet aktivnych a cakajucich skriatkov 0 , vsetci sa skoncia, a santa napokon tiez, a vypise hlasku finished.
		sem_wait(sem_finishSanta);
		vypisy_santa(sharedVar , 2 , sem_vypis);
		vypisy_santa(sharedVar , 4 , sem_vypis); 
		sem_post(sem_finishSanta);
		if(sharedVar->waiting_elves == 0 && sharedVar->working_elves == 0)
			kill(pid_santa, SIGTERM);		//ak je pocet aktivnych a cakajucich skriatkov nulovy, inymi slovami ked je proces skriatka ukonceny, a aj santa je finished, posle mu SIGTERM pre ukoncenie
	}

//Funkcia pre vypisy pre santu
void vypisy_santa(stav *sharedVar, int sprava,sem_t * sem_vypis) {
		sem_wait(sem_vypis); //zapis musi byt vylucny,nemoze viac procesov zapisovat naraz
		switch (sprava)
		{
			case 1:   //START_S
				fprintf(santa,"%ld: santa: started\n" ,(sharedVar->sharedA)++);
				break;
			case 2:   //CHECKED_STATE
				fprintf(santa,"%ld: santa: checked state: %ld: %ld\n" ,(sharedVar->sharedA)++ , (sharedVar->working_elves) ,(sharedVar->waiting_elves));
				break;
			case 3:   //CAN HELP
				fprintf(santa,"%ld: santa: can help\n" ,(sharedVar->sharedA)++);
				break;
			case 4:   //FINISHED
				fprintf(santa,"%ld: santa: finished\n" ,(sharedVar->sharedA)++);
				break;
		}
		fflush(santa);  //Pouzite kvoli spravnemu vypisovaniu
		sem_post(sem_vypis);
}
//Funkcia pre vytvorenie procesu skriatka...
void proces_skriatok(long C, long E, long H, stav *sharedVar, sem_t * sem_vypis,sem_t *sem_santa,sem_t *sem_elf,sem_t *sem_cakaj,sem_t *sem_finishElf,sem_t *sem_finishSanta,long shMem) { 
	for(long i=0 ; i<E; i++) 
	{  
		srand(getpid()*time(NULL));//Pre nahodne hodnoty . getpid je pouzite preto, aby kazdy proces skriatka dostal roznu hodnotu.
		pid_t pid_elf;
		pid_elf=fork(); //Vytvori proces skriatka, ak je navratova hodnota = 0 , jedna sa o potomka , ak je -1 nepodarilo sa vytvorit proces, a ak je > 0 , jedna sa o rodica
			
        if(pid_elf == 0) {		
			vypisy_elf(sharedVar, i, 1, sem_vypis);

			for(int finish=0; finish < C ; finish++) {
				if(H == 0)							// Ak je parameter H=0, tak nastane chyba, pretoze nie je mozne delit nulou 
					usleep((rand() % (H +1))*1000); //Skriatok pracuje. *1000 preto , ze parameter S je v milisekundach , a usleep obsahuje parameter v mikrosekundach
				else
					usleep((rand() % H)*1000);

				vypisy_elf(sharedVar, i, 2, sem_vypis);
				//Pre 3 a menej aktivnych skriatkov
				if(sharedVar->working_elves <= 3) {
					sem_wait(sem_cakaj);	//semafor caka na odomknutie , a odomkne sa vtedy ak sa santa uz forkol a vypisal started

					vypisy_elf(sharedVar, i, 3, sem_vypis);
					
					sem_post(sem_santa);    //Ked vypise Asked for Help odblokuje semafor a moze sa zacat obsluha
					sem_wait(sem_elf);	    // caka na dokoncenie obsluhy, ked tento semafor santa odblokuje, dokoncila sa obsluha a moze vypisat got help

					vypisy_elf(sharedVar, i, 4, sem_vypis);
					
					if(finish == (C-1))		//Ak elf vykonal tolko navstev u Santy kolko bolo definovane paramertrom C, vypise got vacation
						vypisy_elf(sharedVar, i, 5, sem_vypis);

					if(sharedVar->working_elves==0)
						sem_post(sem_finishElf);  //Ak uz ziadny nepracuje, odomkne semafor ktory na to caka, a vypise ze elf skoncil (finished)
												  // Elfovia a santa musia koncit naraz, aj ked v roznom poradi, elf nemoze skoncit hned po tom ako bol obsluzeny
						sem_post(sem_cakaj);	  //Elfovia vypisuju asked for help po jednom, a su po jednom obsluzeni

					if((sharedVar->working_elves == 0) && (sharedVar->waiting_elves == 0))	//Ak uz nieje pritomny ziadny pracujuci elf a ani elf cakajuci na obsluhu		
						sem_post(sem_finishSanta);											//tak sa odomkne semafor pre santu, ze moze proces santa skoncit
				}
				//Pre 4 a viac aktivnych skriatkov
				else if(sharedVar->working_elves > 3) {
					sem_wait(sem_cakaj);	//semafor caka na odomknutie , a odomkne sa vtedy ak sa santa uz forkol a vypisal started.Sluzi na to, aby nepytali viaceri elfovia o obsluhu sucasne.

					vypisy_elf(sharedVar, i, 3, sem_vypis);

					sem_post(sem_santa); //Ked vypise Asked for Help odblokuje semafor a moze sa zacat obsluha
					sem_wait(sem_elf);	 // caka na dokoncenie obsluhy, ked tento semafor santa odblokuje, dokoncila sa obsluha a moze vypisat got help

					vypisy_elf(sharedVar, i, 4, sem_vypis);

					if(sharedVar->waiting_elves == 0)
						sem_post(sem_cakaj);		//inkrementuje hodnotu semaforu ak je pocet elfov cakajuci na obsluhu nulovy. pre vypis asked for help
					else
						sem_post(sem_elf); 		    //Odblokuje semafor pre elfa, toto nastane ak je pocet elfov cakajucich na obsluhu != 0 , vypise got help
					if(finish == (C-1))     		//Ak elf vykonal tolko navstev u Santy kolko bolo definovane paramertrom C, vypise got vacation
					 	vypisy_elf(sharedVar, i, 5, sem_vypis);

					if(sharedVar->working_elves==0)  //Ak uz ziadny nepracuje, odomkne semafor ktory na to caka, a vypise ze elf skoncil (finished)
						sem_post(sem_finishElf);     // Elfovia a santa musia koncit naraz, aj ked v roznom poradi, elf nemoze skoncit hned po tom ako bol obsluzeny

					if((sharedVar->working_elves == 0) && (sharedVar->waiting_elves == 0))	//Ak uz nieje pritomny ziadny pracujuci elf a ani elf cakajuci na obsluhu		
						sem_post(sem_finishSanta); 											//tak sa odomkne semafor pre santu, ze moze proces santa skoncit
				}

			}
			sem_wait(sem_finishElf);		//Tento semafor caka , a ked bude odomknuty tak vypise ze elf skoncil. 
			vypisy_elf(sharedVar, i, 6,sem_vypis);
			sem_post(sem_finishElf);		//Inkrementuje semafor pre ukoncenie elfa, aby sa mohli dalsi elfovia ukoncit
			
			exit(0);
			
		}
		else if(pid_elf == -1)
		{	
			clean(sem_vypis, sem_santa,sem_elf, sem_cakaj, sem_finishElf, sem_finishSanta, sharedVar,shMem);
			fprintf(stderr, "Zlyhalo systemove volanie fork!\n"); //vymaze po sebe semafory aj zdielanu pamat
  			kill(0, SIGTERM);  //Zabije vsetkych elfov ktory sa vytvorili 
  			
  			kill(getppid(), SIGTERM);		
			exit(2);

		}	
		else if(pid_elf > 0) {
		}
	}
}

//Funkcia pre vypisy skriatka
void vypisy_elf(stav *sharedVar, long cislo_skriatka, int sprava, sem_t * sem_vypis) {
		sem_wait(sem_vypis);  //zapis musi byt vylucny,nemoze viac procesov zapisovat naraz
		switch(sprava)
		{
			case 1:   //STARTED
				fprintf(santa, "%ld: elf: %ld: started\n" ,(sharedVar->sharedA)++ , cislo_skriatka+1);
				break;
			case 2:  //NEEDED_HELP
				fprintf(santa, "%ld: elf: %ld: needed help\n" ,(sharedVar->sharedA)++ , cislo_skriatka+1);
				break;				
			case 3:  //ASKED_HELP
				fprintf(santa, "%ld: elf: %ld: asked for help\n" ,(sharedVar->sharedA)++ , cislo_skriatka+1);
				(sharedVar->waiting_elves)++;
				break;
			case 4:  //GOT_HELP
				fprintf(santa, "%ld: elf: %ld: got help\n" ,(sharedVar->sharedA)++ , cislo_skriatka+1);
				(sharedVar->waiting_elves)--;
				break;
			case 5:  //VACATION
				fprintf(santa, "%ld: elf: %ld: got a vacation\n" ,(sharedVar->sharedA)++ , cislo_skriatka+1);
				(sharedVar->working_elves)--; 
				break;
			case 6:  //FINISHED
				fprintf(santa, "%ld: elf: %ld: finished\n" ,(sharedVar->sharedA)++ , cislo_skriatka+1);
				break;
		}
		fflush(santa); //Pouzite kvoli spravnemu vypisovaniu
		sem_post(sem_vypis);
} 
//Funkcia ktora rusi , maze semafory, zdielanu pamat
int clean(sem_t *sem_vypis, sem_t *sem_santa, sem_t *sem_elf, sem_t *sem_cakaj, sem_t *sem_finishElf, sem_t *sem_finishSanta, stav *sharedVar,long shMem) {
	if( (sem_close(sem_vypis) != -1) && 
		(sem_close(sem_santa) != -1) &&	
		(sem_close(sem_elf) != -1) &&	
		(sem_close(sem_cakaj) != -1) &&
		(sem_close(sem_finishElf) != -1) &&
		(sem_close(sem_finishSanta) != -1) &&
		(sem_unlink("/sem1_xsulak04") != -1) &&
		(sem_unlink("/sem2_xsulak04") != -1) && 
		(sem_unlink("/sem3_xsulak04") != -1) &&
		(sem_unlink("/sem4_xsulak04") != -1) &&
		(sem_unlink("/sem5_xsulak04") != -1) &&
		(sem_unlink("/sem6_xsulak04") != -1) &&			
		(munmap(sharedVar, sizeof(stav)) != -1) && 
		(shm_unlink("/sharedMem_xsulak04") != -1) &&
		(close(shMem) != -1)) 
		return 0;
	else 	{
		fprintf(stdout,"Nepodarilo sa dealokovat vsetky semafory alebo zdielanu pamat");
		return 2;
		}
}
		



