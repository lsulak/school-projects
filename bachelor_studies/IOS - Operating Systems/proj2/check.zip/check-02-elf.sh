
# testuje spravnou sekvenci vystupu skritka
# bez zaruky, muze obsahovat chyby a nemusi pokryt vsechny varianty

outf="santa.out"
tr -d " " < ${outf} | grep "elf" > $$

cat $$ | awk -F":" '
    /:started$/ { 
	if (needed[$3]!=0 || asked[$3]!=0 || got[$3]!=0 || vac[$3]!=0 || finished[$3]!=0) print $1, ": elf", $3, "started neni prvni akci"
	if (started[$3]!=0) print $1, ": elf", $3, "started: vicekrat";
	started[$3]++; 
    }
    /:neededhelp$/ { 
	if (started[$3]==0) print $1, ": elf", $3, "needed help: nebyl started";
	if (finished[$3]!=0) print $1, ": elf", $3, "needed help: uz byl finished";
	if (needed[$3]!=0) print $1, ": elf", $3, "needed help: opakovane volani";
	needed[$3]++;
    }
    /:askedforhelp$/ {
	if (started[$3]==0) print $1, ": elf", $3, "asked for help: nebyl started";
	if (finished[$3]!=0) print $1, ": elf", $3, "asked for help: uz byl finished";
	if (needed[$3]==0) print $1, ": elf", $3, "asked for help: needed help nebyl volan";
	if (asked[$3]!=0) print $1, ": elf", $3, "asked for help: opakovane volani";
	asked[$3]++;
    }
    /:gothelp$/ {
	if (started[$3]==0) print $1, ": elf", $3, "got help: nebyl started";
	if (finished[$3]!=0) print $1, ": elf", $3, "got help: uz byl finished";
	if (needed[$3]==0) print $1, ": elf", $3, "got help: needed help nebyl volan";
	if (asked[$3]==0) print $1, ": elf", $3, "got help: asked help nebyl volan";
	needed[$3]=0; asked[$3]=0; got[$3]++;
    }
    /:gotavacation$/ {
	if (started[$3]==0) print $1, ": elf", $3, "got a vacation: nebyl started";
	if (finished[$3]!=0) print $1, ": elf", $3, "got a vacation: uz byl finished";
	if (needed[$3]!=0 || asked[$3]!=0 || got[$3]==0) print $1, ": elf", $3, "got a vacation: pomoc nebyla dokoncena";
	vac[$3]++;
    }
    /:finished$/ { 
	if (started[$3]==0) print $1, ": elf", $3, "finished: nebyl started";
	if (needed[$3]!=0 || asked[$3]!=0 || got[$3]==0) print $1, ": elf", $3, "finished: pomoc nebyla dokoncena";
	if (vac[$3]!=1) print $1, ": elf", $3, "finished: pocet volani vacation neni 1:", vac[$3];
	if (finished[$3]!=0) print $1, ": elf", $3, "finished: volano vicekrat";
	finished[$3]++; 
    }
'

rm $$
