
# testuje spravnou sekvenci cislovani akci a format vystupu (pouze syntax)
# bez zaruky, muze obsahovat chyby

outf="santa.out"
tr -d " " < ${outf} > $$

# test cislovani akci
# tiskne radky s chybnym cislovanim
cat $$ | awk -F":" ' { c++; if (c != $1) print NR, " => ", $1, " : chyba v cislovani akci"; } '

# kontrola sytaxe vystupu
# vytiskne radky, ktere neodpovidaji formatu vytupu
echo "=== radky, ktere neodpovidaji formatu vystupu"

cat $$ | sed '/^[1-9][0-9]*:elf:[1-9][0-9]*:started$/d
/^[1-9][0-9]*:elf:[1-9][0-9]*:neededhelp$/d
/^[1-9][0-9]*:elf:[1-9][0-9]*:askedforhelp$/d
/^[1-9][0-9]*:elf:[1-9][0-9]*:gothelp$/d
/^[1-9][0-9]*:elf:[1-9][0-9]*:gotavacation$/d
/^[1-9][0-9]*:elf:[1-9][0-9]*:finished$/d
/^[1-9][0-9]*:santa:started$/d
/^[1-9][0-9]*:santa:checkedstate:[0-9][0-9]*:[0-9]$/d
/^[1-9][0-9]*:santa:canhelp$/d
/^[1-9][0-9]*:santa:finished$/d'

# kontrola chybejicich vystupu
# tiskne informaci, ktery text ve vystupu chybi
echo "=== chybejici vystupy"
cat $$ | grep '^[1-9][0-9]*:elf:[1-9][0-9]*:started$' >/dev/null || echo "elf started"
cat $$ | grep '^[1-9][0-9]*:elf:[1-9][0-9]*:neededhelp$' >/dev/null || echo "elf needed help"
cat $$ | grep '^[1-9][0-9]*:elf:[1-9][0-9]*:askedforhelp$' >/dev/null || echo "elf asked for help"
cat $$ | grep '^[1-9][0-9]*:elf:[1-9][0-9]*:gothelp$' >/dev/null || echo "elf got help"
cat $$ | grep '^[1-9][0-9]*:elf:[1-9][0-9]*:gotavacation$' >/dev/null || echo "elf got a vacation"
cat $$ | grep '^[1-9][0-9]*:elf:[1-9][0-9]*:finished$' >/dev/null || echo "elf finished"
cat $$ | grep '^[1-9][0-9]*:santa:started$' >/dev/null || echo "santa started"
cat $$ | grep '^[1-9][0-9]*:santa:checkedstate:[0-9][0-9]*:[0-9]$' >/dev/null || echo "santa checked state"
cat $$ | grep '^[1-9][0-9]*:santa:canhelp$' >/dev/null || echo "santa can help"
cat $$ | grep '^[1-9][0-9]*:santa:finished$' >/dev/null || echo "santa finished"


rm $$
