#!/bin/sh
find .le &>/dev/null

if [ $? == 1 ] ; then
   mkdir .le
else   
  cd .le 
  ls -1 | xargs rm -f 2>/dev/null  
  cd ..
fi 
  
  cp $1/* . 
  cp $1/* .le

find .le/.config &>/dev/null

if [ $? == 1 ] ; then
   echo projdir $1 > .le/.config 
else 
   sed -in "s\projdir .*\projdir $1\g"  .le/.config      
fi

