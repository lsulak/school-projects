#!/bin/sh 
find .le &>/dev/null

if [ $? == 1  ] ; then 
   exit 1
else  #ak existuje .le
   
   ignore=$( cat .le/.config | grep -E '^ignore .*' | cut -c "8-" )
   mkdir .le/tmp &>/dev/null
   for ignfile in .le/$ignore ; do 
     mv $ignfile .le/tmp &>/dev/null
   done

   if [ -z $1 ] ; then                 #ak nieje zadany parameter,cp all
      if [ ! -e  ".le/$ignore" ] && [ ! -e ".le/\..*" ] ; then
        cp .le/* . 2>/dev/null
      fi
   else 
      while [ -n "$1" ] 
      do
        cp .le/$1 . 2>/dev/null         #vzdy sa bude kopirovat 1.argument
        if [ $? == 0 ] ; then 
          shift

          if [ $? -ne 0 ] ; then      #chyba (neex.)-vynecha a opak. smycku 
            break
          fi
            break 
        fi 
          shift                       #dalsie sa budu posuvat na poziciu 1. 
     done   
   fi
   if [ -d .le/tmp ] ; then
     mv .le/tmp/* .le/ &>/dev/null
     rm -r .le/tmp
   fi

fi
