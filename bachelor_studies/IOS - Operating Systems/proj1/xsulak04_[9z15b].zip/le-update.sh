#!/bin/sh
 projdir=$( cat .le/.config | grep -o '^projdir .*' | cut -c "9-" )
 ignore=$( cat .le/.config | grep -E '^ignore .*' | cut -c "8-" )
  if [ -z $1 ] ; then    #ak nieje zadany parameter
 
  for fileM in $projdir/* ; do
    fileMpom=$( basename $fileM )
      if [ ! -f "$fileMpom" ] ; then #6.krok=neex.v exp, no ex. v projdir
        cp $fileM $fileMpom
        cp $fileM .le/$fileMpom
        echo C: $fileMpom
      fi

      if [ -f "$fileMpom" ] && [ -f ".le/$fileMpom" ] ; then 
      #ak existuje vo vsetkych 3 adresaroch
        diff -s "$fileM" ".le/$fileMpom"  &>/dev/null #projdir=.le
        if [ $? == 0 ] ; then
          if diff "$fileM" "$fileMpom"  &>/dev/null ; then  
            echo .: $fileMpom                         # = exp
              else
              echo M: $fileMpom                       # != exp
          fi
        fi

        diff -s "$fileM" "$fileMpom"  &>/dev/null #projdir=exp
        if [ $? == 0 ] ; then
          if diff "$fileM" ".le/$fileMpom"  &>/dev/null ; then  # != .le
            true
          else
            echo UM: $fileMpom
            cp $fileM .le/$fileMpom
          fi
        fi
      fi
  done

  for fileD in .le/* ; do  #7.krok , ex. v .le, neex. v projdir
    fileDpom=$( basename $fileD )
    if [ ! -f "$projdir/$fileDpom" ] ; then
      echo D: $fileDpom
      rm $fileD $fileDpom &>/dev/null
    fi
  done

  for fileU in * ; do
    fileUpom=$( basename $fileU )
      if [ -f "$fileU" ] && [ -f ".le/$fileU" ] ; then
      #Ak existuje vo vsetkych 3 adresaroch
        diff -s "$fileU" ".le/$fileU" &>/dev/null    #exp=.le
          if [ $? == 0 ] ; then 
            if diff "$fileU" "$projdir/$fileU" &>/dev/null; then  #!=projdir
              true
            else
              echo U: $fileU
              cp "$projdir/$fileU" "$fileU"
              cp "$projdir/$fileU" ".le/$fileU"
           fi
          else
            if ! diff -s ".le/$fileU" "$projdir/$fileU" &>/dev/null ; then
              if ! diff -s "$fileU" "$projdir/$fileU" &>/dev/null ; then  
               diff -u "$projdir/$fileU" ".le/$fileU" >$fileU.patch
               patch -s $fileU $fileU.patch  &>/dev/null
                if [ $? -ne 0 ] ; then
                  echo M!: $fileU conflict!
                  rm $fileU.patch $fileU.rej $fileU.orig &>/dev/null
                else 
                  echo M+: $fileU
                  cp $projdir/$fileU .le/$fileU  
                  rm $fileU.patch $fileU.rej $fileU.orig &>/dev/null 
                fi
              fi
            fi
          fi
      fi
  done
else   #PRE CAST S 1+ PARAMETRAMI!!
for fileM2 in "$projdir/$@" ; do
  fileM2pom=$( basename $fileM2 )
  if [ -f "$fileM2" ] && [ ! -f "$fileM2pom" ] ; then
    cp $fileM2 $fileMpom 2>/dev/null
    cp $fileM2 .le/$fileM2pom 2>/dev/null
    echo C: $fileM2pom
  fi

  if [ -f "$fileM2" ] && [ -f "$fileM2pom" ] && [ -f ".le/$fileM2pom" ] ; then
    diff -s "$fileM2" ".le/$fileM2pom" &>/dev/null
    if [ $? == 0 ] ; then
      if diff "$fileM2" "$fileM2pom" &>/dev/null ; then
        echo .: $fileM2pom
      else
        echo M: $fileM2pom
      fi
    fi

   diff -s "$fileM2" "$fileM2pom" &>/dev/null
   if [ $? == 0 ] ; then
     if diff "$fileM2" ".le/$fileM2pom" &>/dev/null ; then 
       true
     else
       echo UM: $fileM2pom
       cp $fileM2 .le/$fileM2pom 2>/dev/null
     fi
   fi
  fi
done

for fileD2 in .le/$@ ; do 
    fileD2pom=$( basename $fileD2 )
    if [ -f "$fileD2" ] && [ ! -f "$projdir/$fileD2pom" ] ; then
      echo D: $fileD2pom
      rm $fileD2 $fileD2pom &>/dev/null
    fi
  done

for fileU2 in $@ ; do
    fileU2pom=$( basename $fileU2 )
      if [ -f "$fileU2" ] && [ -f "$fileU2pom" ] && [ -f ".le/$fileU2pom" ] ; then
      #Ak existuje vo vsetkych 3 adresaroch
        diff -s "$fileU2" ".le/$fileU2" &>/dev/null    #exp=.le
          if [ $? == 0 ] ; then 
            if diff "$fileU2" "$projdir/$fileU2" &>/dev/null; then  #!=projdir
              true
            else
              echo U: $fileU2
              cp "$projdir/$fileU2" "$fileU2" 2>/dev/null
              cp "$projdir/$fileU2" ".le/$fileU2" 2>/dev/null
            fi
          else
            if ! diff -s ".le/$fileU2" "$projdir/$fileU2" &>/dev/null ; then
              if ! diff -s "$fileU2" "$projdir/$fileU2" &>/dev/null ; then  
               diff -u "$projdir/$fileU2" ".le/$fileU2" >$fileU.patch 2>/dev/null
               patch -s "$fileU2" "$fileU2.patch" &>/dev/null 
                if [ $? -ne 0 ] ; then
                  echo M!: $fileU2 conflict!
                  rm $fileU2.patch $fileU2.rej $fileU2.orig &>/dev/null
                else
                  echo M+: $fileU2
                  cp $projdir/$fileU2 .le/$fileU2 2>/dev/null
                  rm $fileU2.patch $fileU2.rej $fileU2.orig &>/dev/null  
                fi
              fi
            fi
          fi
      fi
  done
fi     
