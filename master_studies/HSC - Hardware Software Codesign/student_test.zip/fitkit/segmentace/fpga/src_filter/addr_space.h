#ifndef __ADDR_SPACE__
#define __ADDR_SPACE__

#define FPGA_HISTOGRAM	0
#define FPGA_MCU_READY	8
#define FPGA_THRESHOLD  9
#define FPGA_FRAME_CNT  10

#endif
